//
//  PilotDetailVC.h
//  FlightControl
//
//  Created by Domagoj Grizelj on 04/02/2018.
//  Copyright © 2018 Domagoj Grizelj. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Pilot.h"

@interface PilotDetailVC : UIViewController

@property (nonatomic, strong) Pilot *pilot;
@property BOOL isEmpty;

@end
