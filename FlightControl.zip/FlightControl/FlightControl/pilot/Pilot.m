//
//  Pilot.m
//  FlightControl
//
//  Created by Domagoj Grizelj on 03/02/2018.
//  Copyright © 2018 Domagoj Grizelj. All rights reserved.
//

#import "Pilot.h"

@implementation Pilot

+ (RKObjectMapping *)getObjectMapping {
    RKObjectMapping *pilotMapping = [RKObjectMapping mappingForClass:[Pilot class]];
    
    NSDictionary *mappingDictionary = @{@"FirstName" : @"firstName",
                                        @"LastName" : @"lastName",
                                        @"BirthDay" : @"birthDay",
                                        @"Active" : @"active",
                                        @"Id" : @"pilotId"};
    
    [pilotMapping addAttributeMappingsFromDictionary:mappingDictionary];
    return pilotMapping;
}

@end
