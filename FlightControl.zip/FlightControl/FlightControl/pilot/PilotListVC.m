//
//  PilotListVC.m
//  FlightControl
//
//  Created by Domagoj Grizelj on 03/02/2018.
//  Copyright © 2018 Domagoj Grizelj. All rights reserved.
//

#import "PilotListVC.h"
#import <RestKit/RestKit.h>
#import "Pilot.h"
#import "PilotDetailVC.h"

@interface PilotListVC ()

@property (weak, nonatomic) IBOutlet UITableView *tableView;
- (IBAction)addAction:(id)sender;

@property (strong, nonatomic) NSArray *items;
@property NSUInteger selectedIndexRow;

@end

@implementation PilotListVC


- (void)viewDidLoad {
    [super viewDidLoad];

    _items = [[NSArray alloc] init];
    [self loadData];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}


-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    NSLog(@"returnanje broja rowowa");
    return _items.count;
}


-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"DetailCell" forIndexPath:indexPath];
    
    Pilot *pilot = [self.items objectAtIndex:indexPath.row];
    
    cell.textLabel.text = [NSString stringWithFormat:@"%@ %@", pilot.firstName, pilot.lastName];
    
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    _selectedIndexRow = indexPath.row;
    [self performSegueWithIdentifier:@"PilotListToPilotDetail" sender:self];
}


- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        //[self deleteDataForRow:indexPath];
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }
}


-(void)loadData {
    
    // setup object mappings
    RKObjectMapping *pilotMapping = [Pilot getObjectMapping];
    
    // register mappings with the provider using a response descriptor
    RKResponseDescriptor *responseDescriptor = [RKResponseDescriptor responseDescriptorWithMapping:pilotMapping
                                                                                            method:RKRequestMethodGET
                                                                                       pathPattern:@"/pilot"
                                                                                           keyPath:nil
                                                                                       statusCodes:[NSIndexSet indexSetWithIndex:200]];
    [[RKObjectManager sharedManager] addResponseDescriptor:responseDescriptor];
    
    [[RKObjectManager sharedManager] getObjectsAtPath:@"/pilot"
                                           parameters:nil
                                              success:^(RKObjectRequestOperation *operation, RKMappingResult *mappingResult) {
                                                  NSLog(@"Loaded databases: %@", mappingResult.array);
                                                  _items = mappingResult.array;
                                                  [self.tableView reloadData];
                                              }
                                              failure:^(RKObjectRequestOperation *operation, NSError *error) {
                                                  NSLog(@"Error on loading: %@", [error localizedDescription]);
                                              }];
}



#pragma mark - Navigation

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    if ([[segue identifier]  isEqual: @"PilotListToPilotDetail"]) {
        PilotDetailVC *vc = [segue destinationViewController];
        vc.pilot = _items[_selectedIndexRow];
        vc.isEmpty = NO;
    } else if ([[segue identifier]  isEqual: @"AddPilot"]) {
        PilotDetailVC *vc = [segue destinationViewController];
        vc.pilot = [[Pilot alloc] init];
        vc.isEmpty = YES;
    }
}

- (IBAction)addAction:(id)sender {
    [self performSegueWithIdentifier:@"AddPilot" sender:self];
}
@end
