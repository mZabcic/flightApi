//
//  PilotDetailVC.m
//  FlightControl
//
//  Created by Domagoj Grizelj on 04/02/2018.
//  Copyright © 2018 Domagoj Grizelj. All rights reserved.
//

#import "PilotDetailVC.h"
#import <RestKit/RestKit.h>
#import "TimeDateHelpers.h"

@interface PilotDetailVC ()
@property (weak, nonatomic) IBOutlet UILabel *ActiveOutlet;
@property (weak, nonatomic) IBOutlet UISwitch *switchOutlet;
@property (weak, nonatomic) IBOutlet UITextField *nameTextField;
@property (weak, nonatomic) IBOutlet UITextField *surnameTextField;
@property (weak, nonatomic) IBOutlet UITextField *birthdayTextField;
@property (weak, nonatomic) IBOutlet UITextField *idTextField;

@property (weak, nonatomic) IBOutlet UIButton *saveButtonOutlet;

- (IBAction)switchAction:(id)sender;
- (IBAction)editAction:(id)sender;
- (IBAction)saveButtonAction:(id)sender;


@end
@implementation PilotDetailVC

- (void)viewDidLoad {
    [super viewDidLoad];
    [self setupView];
    
    NSLog(@"isempty %d", _isEmpty);

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (void)setupView {
    
    if (_pilot.active == YES) {
        _ActiveOutlet.text = @"AKTIVAN";
        _ActiveOutlet.textColor = [UIColor greenColor];
        [_switchOutlet setOn:YES];
    } else {
        _ActiveOutlet.text = @"NEAKTIVAN";
        _ActiveOutlet.textColor = [UIColor redColor];
        [_switchOutlet setOn:NO];
    }
    
    _nameTextField.text = _pilot.firstName;
    _surnameTextField.text = _pilot.lastName;
    
    _birthdayTextField.text = [TimeDateHelpers getStringFromDate:_pilot.birthDay];
    _idTextField.text = [NSString stringWithFormat:@"%d", _pilot.pilotId];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)switchAction:(id)sender {
    if (_switchOutlet.isOn) {
        _ActiveOutlet.text = @"AKTIVAN";
        _ActiveOutlet.textColor = [UIColor greenColor];
    } else {
        _ActiveOutlet.text = @"NEAKTIVAN";
        _ActiveOutlet.textColor = [UIColor redColor];
    }
    
}

- (IBAction)editAction:(id)sender {
    _switchOutlet.enabled = YES;
    _nameTextField.enabled = YES;
    _surnameTextField.enabled = YES;
    _birthdayTextField.enabled = YES;
    _saveButtonOutlet.enabled = YES;
    _idTextField.enabled = YES;
}

- (IBAction)saveButtonAction:(id)sender {
    _pilot.firstName = _nameTextField.text;
    _pilot.lastName = _surnameTextField.text;
    _pilot.active = _switchOutlet.isOn;
    _pilot.birthDay = [TimeDateHelpers getDateFromString:_birthdayTextField.text];
    _pilot.pilotId = _idTextField.text.integerValue;
    
    NSLog(@"pilot ime: %@", _pilot.firstName);
    
    
    NSLog(@"pilot aktivan: %d", _pilot.active);
    
    [self saveData];
    
    
}

- (void)saveData {
    
    if (_isEmpty == YES) {
        RKRequestDescriptor *requestDescriptor = [RKRequestDescriptor requestDescriptorWithMapping:[Pilot getObjectMapping].inverseMapping
                                                                                       objectClass:[Pilot class]
                                                                                       rootKeyPath:nil
                                                                                            method:RKRequestMethodAny];
    
        [[RKObjectManager sharedManager] addRequestDescriptor:requestDescriptor];
        
        [[RKObjectManager sharedManager] postObject:_pilot
                                              path:@"/pilot"
                                        parameters:nil
                                           success:nil
                                           failure:nil
         ];
    } else {
        RKRequestDescriptor *requestDescriptor = [RKRequestDescriptor requestDescriptorWithMapping:[Pilot getObjectMapping].inverseMapping
                                                                                       objectClass:[Pilot class]
                                                                                       rootKeyPath:nil
                                                                                            method:RKRequestMethodAny];
        
        [[RKObjectManager sharedManager] addRequestDescriptor:requestDescriptor];
        
        [[RKObjectManager sharedManager] putObject:_pilot path:[NSString stringWithFormat:@"/pilot/%d", _pilot.pilotId]
                                        parameters:nil
                                           success:^(RKObjectRequestOperation *operation, RKMappingResult *mappingResult) {
                                               NSLog(@"success stari");
                                           }
                                           failure:^(RKObjectRequestOperation *operation, NSError *error) {
                                               NSLog(@"fail stari");
                                           }];
    }
    
    
}


@end
