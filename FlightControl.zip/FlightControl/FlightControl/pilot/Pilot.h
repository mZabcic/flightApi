//
//  Pilot.h
//  FlightControl
//
//  Created by Domagoj Grizelj on 03/02/2018.
//  Copyright © 2018 Domagoj Grizelj. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <RestKit/RestKit.h>

@interface Pilot : NSObject

@property (nonatomic, strong) NSString *firstName;
@property (nonatomic, strong) NSString *lastName;
@property (nonatomic, strong) NSDate *birthDay;
@property BOOL active;
@property NSInteger pilotId;

+(RKObjectMapping *)getObjectMapping;

@end
