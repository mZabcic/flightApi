//
//  TimeDateHelpers.m
//  FlightControl
//
//  Created by Domagoj Grizelj on 05/02/2018.
//  Copyright © 2018 Domagoj Grizelj. All rights reserved.
//

#import "TimeDateHelpers.h"

@implementation TimeDateHelpers

+(NSString *)getStringFromDate:(NSDate *)date {
    NSDateFormatter *dateFormat = [[NSDateFormatter alloc]init];
    [dateFormat setDateFormat:@"yyyy'-'MM'-'dd'T'HH':'mm':'ss.SSS'Z'"];// this string must match given string @"2015-05-08T09:44:25.343"
    
    [dateFormat setDateFormat:@"dd.MM.yyyy"];// this match the one you want to be
    NSString *convertedString = [dateFormat stringFromDate:date];
    return convertedString;
}


+(NSDate *)getDateFromString:(NSString *)stringDate {
    NSDateFormatter *dateFormat = [[NSDateFormatter alloc]init];
    [dateFormat setDateFormat:@"dd.MM.yyyy"];
    
    NSDate *date = [dateFormat dateFromString:stringDate];
    
    [dateFormat setDateFormat:@"yyyy'-'MM'-'dd'T'HH':'mm':'ss.SSS'Z'"];
    return date;    
}


@end
