//
//  TimeDateHelpers.h
//  FlightControl
//
//  Created by Domagoj Grizelj on 05/02/2018.
//  Copyright © 2018 Domagoj Grizelj. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TimeDateHelpers : NSObject

+(NSString *)getStringFromDate:(NSDate *)date;

+(NSDate *)getDateFromString:(NSString *)stringDate;

@end
