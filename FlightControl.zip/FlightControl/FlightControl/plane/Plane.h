//
//  Plane.h
//  FlightControl
//
//  Created by Domagoj Grizelj on 05/02/2018.
//  Copyright © 2018 Domagoj Grizelj. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <RestKit/RestKit.h>

@interface Plane : NSObject

@property (nonatomic, strong) NSString *model;
@property (nonatomic, strong) NSString *serialNumber;
@property NSInteger economyCapacity;
@property NSInteger businessCapacity;
@property NSInteger firstClassCapacity;
@property NSInteger planeId;
@property NSInteger active;

+(RKObjectMapping *)getObjectMapping;

@end


