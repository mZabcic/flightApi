//
//  Plane.m
//  FlightControl
//
//  Created by Domagoj Grizelj on 05/02/2018.
//  Copyright © 2018 Domagoj Grizelj. All rights reserved.
//

#import "Plane.h"

@implementation Plane

+ (RKObjectMapping *)getObjectMapping {
    RKObjectMapping *pilotMapping = [RKObjectMapping mappingForClass:[Plane class]];
    
    NSDictionary *mappingDictionary = @{@"Model" : @"model",
                                        @"SerialNumber" : @"serialNumber",
                                        @"EconomyCapacity" : @"economyCapacity",
                                        @"BusinessCapacity" : @"businessCapacity",
                                        @"FirstClassCapacity" : @"firstClassCapacity",
                                        @"Active" : @"active",
                                        @"Id" : @"planeId"
                                        };
    
    [pilotMapping addAttributeMappingsFromDictionary:mappingDictionary];
    return pilotMapping;
}


@end

