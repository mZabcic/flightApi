//
//  FlightControlRestClient.m
//  FlightControl
//
//  Created by Domagoj Grizelj on 04/02/2018.
//  Copyright © 2018 Domagoj Grizelj. All rights reserved.
//

#import "FlightControlRestClient.h"

@implementation FlightControlRestClient

+(void)initializeRestKit {
    
    
    
}

@end
