//
//  FlightControlRestGateway.m
//  FlightControl
//
//  Created by Domagoj Grizelj on 03/02/2018.
//  Copyright © 2018 Domagoj Grizelj. All rights reserved.
//

#import "FlightControlRestGateway.h"

@implementation FlightControlRestGateway

@end
