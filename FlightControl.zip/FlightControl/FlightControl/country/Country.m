//
//  Country.m
//  FlightControl
//
//  Created by Domagoj Grizelj on 05/02/2018.
//  Copyright © 2018 Domagoj Grizelj. All rights reserved.
//

#import "Country.h"

@implementation Country

+ (RKObjectMapping *)getObjectMapping {
    RKObjectMapping *pilotMapping = [RKObjectMapping mappingForClass:[Country class]];
    
    NSDictionary *mappingDictionary = @{@"iso" : @"iso",
                                        @"name" : @"name",
                                        @"printable_name" : @"printableName",
                                        @"iso3" : @"iso3",
                                        @"numcode" : @"numcode",
                                        @"Id" : @"countryId"
                                        };
    
    [pilotMapping addAttributeMappingsFromDictionary:mappingDictionary];
    return pilotMapping;
}

@end
