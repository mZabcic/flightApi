//
//  Country.h
//  FlightControl
//
//  Created by Domagoj Grizelj on 05/02/2018.
//  Copyright © 2018 Domagoj Grizelj. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <RestKit/RestKit.h>

@interface Country : NSObject

@property (nonatomic, strong) NSString *iso;
@property (nonatomic, strong) NSString *name;
@property (nonatomic, strong) NSString *printableName;
@property (nonatomic, strong) NSString *iso3;
@property NSInteger numcode;
@property NSInteger countryId;

+(RKObjectMapping *)getObjectMapping;



@end
